#!/bin/bash

echo "starting plain js app"
python3 -m http.server 20002
