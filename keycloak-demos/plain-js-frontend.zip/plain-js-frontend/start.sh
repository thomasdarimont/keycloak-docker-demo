#!/bin/bash

python -m SimpleHTTPServer 20002
